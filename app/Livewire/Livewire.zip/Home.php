<?php

namespace App\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Http; // Tambahkan ini

class Home extends Component
{
    public $chart;
    public $date;
    public $data;
    public function mount() {
        $date = date('Y-m-d');
        $this->date = $date;
        $response = Http::post("https://hirumi.xyz/pasar_2025_web/api" . '/home', ["tanggal" => $date]); // Ganti 'URL_API' dengan URL API yang sesuai

        $this->data = json_decode($response)->data;
    }
    public function render()
    {
        return view('livewire.home');
    }
}

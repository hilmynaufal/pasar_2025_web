<div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('nav-bar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4186694346-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_settings-panel.html -->
        <?php echo $__env->make('livewire.floating-button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('livewire.sidebar-right', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- partial -->
        <!-- partial:partials/_sidebar.html -->
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('sidebar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4186694346-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <div class="mb-0" style="margin-right:4px">
                                <div class="grid-margin">
                                    <div class="row">
                                        <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                                            <h3 class="font-weight-bold">Tagihan</h3>
                                            <p class="card-description">
                                                Semua tagihan di <?php echo e(session('nama_pasar')); ?> pada Tanggal <?php echo e($date); ?>

                                            </p>
                                        </div>
                                        <div class="col-12 col-xl-4">
                                            <div class="justify-content-end d-flex">
                                                <div class="flex-md-grow-1 flex-xl-grow-0">
                                                    <p class="card-description">
                                                        Pilih Tanggal
                                                    </p>
                                                    <input class="form-control form-control-sm text-primary"
                                                        wire:model="date" name="date" wire:key="ahay"
                                                        id="kt_datepicker_1" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex flex-wrap mb-5">
                                <div class="mr-5 mt-3">
                                    <p class="text-muted">Total Tagihan Belum Dibayar</p>
                                    <h3 id="total_belum_dibayar" class="text-primary fs-30 font-weight-medium">0</h3>
                                </div>
                                <div class="mr-5 mt-3">
                                    <p class="text-muted">Total Tagihan Sudah Dibayar</p>
                                    <h3 id="total_sudah_dibayar" class="text-primary fs-30 font-weight-medium">0</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="table-responsive">
                                        <table id="tagihan" class="table table-striped compact" style="width:100%">
                                            <thead>
                                                <tr>
                                                    <th>Pedagang</th>
                                                    <th>Status</th>
                                                    <th>Pasar</th>
                                                    <th>Tanggal</th>
                                                    <th>Kode Kios</th>
                                                    <th>Tipe</th>
                                                    <th> Tarif</th>
                                                    <th>Id Transaksi</th>
                                                    <th>Salesman</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content-wrapper ends -->
            <!-- partial:partials/_footer.html -->
            <footer class="footer">
                <div class="d-sm-flex justify-content-center justify-content-sm-between">
                    <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2021.
                        Premium <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap admin
                            template</a> from BootstrapDash. All rights reserved.</span>
                    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made
                        with <i class="ti-heart text-danger ml-1"></i></span>
                </div>
                <div class="d-sm-flex justify-content-center justify-content-sm-between">
                    <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Distributed by <a
                            href="https://www.themewagon.com/" target="_blank">Themewagon</a></span>
                </div>
            </footer>
            <!-- partial -->
        </div>
        <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->


    <?php
        $__scriptKey = '4186694346-0';
        ob_start();
    ?>
<script>
    document.addEventListener('livewire:navigated', function () {

        var settings = {
            "url": "https://hirumi.xyz/pasar_2025_web/api/tagihan_stat",
            "method": "POST",
            "timeout": 0,
            "data": {
                "tanggal": "<?php echo e($date); ?>",
                "nama_pasar": '<?php echo e(session('nama_pasar')); ?>'
            }
        };

        $.ajax(settings).done(function (response) {
            console.log(response);
            $('#total_sudah_dibayar').text(response['data']['totalSudahDibayar']);
            $('#total_belum_dibayar').text(response['data']['totalBelumDibayar']);
        })

        var settings = {
            "url": "https://hirumi.xyz/pasar_2025_web/api/tagihan",
            "method": "POST",
            "timeout": 0,
            "data": {
                "tanggal": "<?php echo e($date); ?>",
                "nama_pasar": '<?php echo e(session('nama_pasar')); ?>'
            }
        };

        $.ajax(settings).done(function (response) {

            console.log(response);
            var table = $('#tagihan').DataTable({
                "pageLength": 25,
                "data": response['data'],
                "columns": [
                    {
                        "data": "pedagang"
                    },
                    {
                        "data": "status",
                        "render": function (data, type, row) {
                            var s = data == 0 ? '<label class="badge badge-danger">Belum Dibayar</label>' : '<label class="badge badge-success">Sudah Dibayar</label>';
                            return s;
                        }
                    },
                    { "data": "merchant_id" },
                    { "data": "tanggal_tagihan" },
                    { "data": "id_kios" },
                    {
                        "data": "invoice_type", "render": function (data, type, row) {
                            return '<b>' + data + '</b>';
                        }
                    },
                    {
                        "data": "tarif",
                        "render": function (data, type, row) {
                            var s = 'Rp. ' + data;
                            return s;
                        }
                    },
                    { "data": "transaction_id" },
                    { "data": "salesman" },
                    {
                        "className": 'details-control',
                        "orderable": false,
                        "data": null,
                        "defaultContent": ''
                    }
                ],
                "order": [[0, 'asc']],
                "paging": true,
                "ordering": true,
                "info": false,
                "filter": true,
                "layout": {
                    // topStart: 'search',
                    "topEnd": 'search'
                },
                columnDefs: [{
                    orderable: true,
                    className: 'select-checkbox',
                    targets: 0
                }],
                select: {
                    style: 'os',
                    selector: 'td:first-child'
                }
            });
        });

        var a = $("#kt_datepicker_1").flatpickr({
            "setDate": new Date(),
            "autoclose": true,
            "onChange": function (selectedDates, dateStr, instance) {
                console.log(dateStr);
                var settings = {
                    "url": "https://hirumi.xyz/pasar_2025_web/api/tagihan",
                    "method": "POST",
                    "timeout": 0,
                    "data": {
                        "tanggal": dateStr,
                        "nama_pasar": '<?php echo e(session('nama_pasar')); ?>'
                    }
                };

                $.ajax(settings).done(function (response) {
                    $('#tagihan').DataTable().clear().rows.add(response['data']).draw();
                })

                var settings = {
                    "url": "https://hirumi.xyz/pasar_2025_web/api/tagihan_stat",
                    "method": "POST",
                    "timeout": 0,
                    "data": {
                        "tanggal": dateStr,
                        "nama_pasar": '<?php echo e(session('nama_pasar')); ?>'
                    }
                };

                $.ajax(settings).done(function (response) {
                    console.log(response);
                    $('#total_sudah_dibayar').text(response['data']['totalSudahDibayar']);
                    $('#total_belum_dibayar').text(response['data']['totalBelumDibayar']);
                })

            }
        });
    });

</script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?><?php /**PATH G:\gawean\pasar_2025_web\resources\views/livewire/tagihan.blade.php ENDPATH**/ ?>